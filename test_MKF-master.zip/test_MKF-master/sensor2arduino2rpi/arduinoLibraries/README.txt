
copy these to ~/Arduino/libraries/

source:
https://github.com/jrowberg/i2cdevlib
